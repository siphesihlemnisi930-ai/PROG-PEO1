/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginreg;
import java.util.ArrayList; // Used to store in a list
import java.util.Scanner;   // Used to read input from keyboard
import java.util.regex.Pattern; // Used for pattern checking (e.g.,password, phone numbers)
/**
 * 
 * @author Horace
 */
public class LoginReg {
       // Scanner :Our way of talking to the program
   static Scanner scanner = new Scanner(System.in);
 
   // A"basket" where we keep all registered users
   static ArrayList<User> users = new ArrayList<>();
 
   // This will remember if login worked or not
   static String loginStatusMessage = "";
 

    public static void main(String[] args) {
              // First lets register someone
       String regResult = registerUser();
       // Tell the user if registration was successful
       System.out.println(regResult);
 
       // Now try to login in with the details we just added 
       boolean loggedIn = loginUser();
       // Show the login result using the returnLoginStatus method
       System.out.println(returnLoginStatus(loggedIn));
    }
 
   // This inner class is like a "blueprint"it remembers their first name, last name phone,etc
   static class User {
       String firstName;
       String lastName;
       String phoneNumber;
       String username;
       String password;
 
       // The constructer stores those details inside the object
       User(String firstName, String lastName, String phoneNumber, String username, String password) {
           this.firstName = firstName;
           this.lastName = lastName;
           this.phoneNumber = phoneNumber;
           this.username = username;
           this.password = password;
       }
   }
 
   // This method is like a gatekeeper for username , A username must contain an UNDERSCORE AND 5 characters
   public static boolean checkUserName(String username) {
       if (username.contains("_")) {
           if (username.length() <= 5) {
               return true;
           } else {
               return false;
           }
       } else {
           return false;
       }
   }
 
   // Validates whether the password meeet security rules using regex
   public static boolean checkPasswordComplexity(String password) {
       // Password must have a capital letter, number, special character, and be 8+ characters long
       String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/~`|]).{8,}$";
       boolean matches = Pattern.matches(pattern, password);
       return matches;
   }
 
   // Verify whether the phone number starts with +27 and has exactly 9 digits after
   public static boolean checkCellPhoneNumber(String phoneNumber) {
       String pattern = "^\\+27\\d{9}$";
       return Pattern.matches(pattern, phoneNumber);
   }
 
   // Manages the user registration process
   public static String registerUser() {
       System.out.println("--- User Registration ---");
 
       // Request the user's first name record it
       System.out.print("Enter First Name: ");
       String firstName = scanner.nextLine();
 
       // Request the user's Last name
       System.out.print("Enter Last Name: ");
       String lastName = scanner.nextLine();
 
       // Continue prompting until username passes validation
       String username = "";
       boolean validUsername = false;
       while (validUsername == false) {
           System.out.print("Enter Username (Username must have underscore  _ and maximum of 5 chars): ");
           username = scanner.nextLine();
           validUsername = checkUserName(username);
 
           if (validUsername == false) {
               System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
           } else {
               System.out.println("Username successfully captured.");
           }
       }
 
       // Loop to keep asking until a valid password is entered
       String password = "";
       boolean validPassword = false;
       while (validPassword == false) {
           System.out.print("Enter Password: ");
           password = scanner.nextLine();
           validPassword = checkPasswordComplexity(password);
 
           if (validPassword == false) {
               System.out.println("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
           } else {
               System.out.println("Password successfully captured.");
           }
       }
 
       // Loop to keep asking until a valid phone number is entered
       String phoneNumber = "";
       boolean phoneOK = false;
       while (phoneOK == false) {
           System.out.print("Enter Cell Phone (+27xxxxxxxxx): ");
           phoneNumber = scanner.nextLine();
           phoneOK = checkCellPhoneNumber(phoneNumber);
 
           if (phoneOK == false) {
               System.out.println("Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.");
           } else {
               System.out.println("Cell number successfully captured.");
           }
       }
 
       // Add the new user to the list of registered users
       users.add(new User(firstName, lastName, phoneNumber, username, password));
 
       // Confirm successful registration
       return "Registration complete!";
   }
 
   // Purpose:Handles user Login
   public static boolean loginUser() {
       System.out.println("User Login");
 
       // Ask the user to enter  their username
       System.out.print("Enter Username: ");
       String usernameInput = scanner.nextLine();
 
       // Search for a user with the matching username
       for (int i = 0; i < users.size(); i++) {
           User currentUser = users.get(i);
 
           // Check if entered username matches a stored one
           if (currentUser.username.equals(usernameInput)) {
               boolean passwordCorrect = false;
 
               // keep promting until the correct password is entered
               while (!passwordCorrect) {
                   System.out.print("Enter Password: ");
                   String passwordInput = scanner.nextLine();
 
                   // If the password matches, set the message and return true
                   if (currentUser.password.equals(passwordInput)) {
                       loginStatusMessage = "Welcome " + currentUser.firstName + ", " + currentUser.lastName + " it is great to see you again.";
                       return true;
                   } else {
                       // If password is wrong, try again
                       System.out.println("Password incorrect. Please try again.");
                   }
               }
           }
       }
 
       //If the system canncone locate the username 
       loginStatusMessage = "Username not found. Please register first.";
       return false;
   }
 
   // Return the message that indicates the login outcome
   public static String returnLoginStatus(boolean status) {
       return loginStatusMessage;
   }
}
        
    

