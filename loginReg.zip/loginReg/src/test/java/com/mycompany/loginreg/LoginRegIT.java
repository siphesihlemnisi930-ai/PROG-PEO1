/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginreg;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Horace
 */
public class LoginRegIT {
    
    public LoginRegIT() {
    }

    @org.junit.jupiter.api.Test
    public void testMain() {
    }

    @org.junit.jupiter.api.Test
    public void testCheckUserName() {
    }

    @org.junit.jupiter.api.Test
    public void testCheckPasswordComplexity() {
    }

    @org.junit.jupiter.api.Test
    public void testCheckCellPhoneNumber() {
    }

    @org.junit.jupiter.api.Test
    public void testRegisterUser() {
    }

    @org.junit.jupiter.api.Test
    public void testLoginUser() {
    }

    @org.junit.jupiter.api.Test
    public void testReturnLoginStatus() {
    }
    
}
